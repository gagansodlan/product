import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '@/types';
import { users } from '@/mocks/users';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
      
      login: async (email, password) => {
        set({ isLoading: true, error: null });
        
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          // Mock authentication - in a real app, this would be an API call
          const user = users.find(u => u.email === email);
          
          if (user && password === 'password') { // Simple mock password check
            set({ user, isAuthenticated: true, isLoading: false });
          } else {
            set({ error: 'Invalid email or password', isLoading: false });
          }
        } catch (error) {
          set({ error: 'An error occurred during login', isLoading: false });
        }
      },
      
      register: async (name, email, password) => {
        set({ isLoading: true, error: null });
        
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          // Check if user already exists
          const existingUser = users.find(u => u.email === email);
          
          if (existingUser) {
            set({ error: 'User with this email already exists', isLoading: false });
            return;
          }
          
          // Create new user (in a real app, this would be an API call)
          const newUser: User = {
            id: `user-${Date.now()}`,
            name,
            email,
            // In a real app, you would never store the password in the client
          };
          
          // In a real app, you would add the user to the database
          // For this mock, we'll just set the user as logged in
          set({ user: newUser, isAuthenticated: true, isLoading: false });
        } catch (error) {
          set({ error: 'An error occurred during registration', isLoading: false });
        }
      },
      
      logout: () => {
        set({ user: null, isAuthenticated: false });
      },
      
      clearError: () => {
        set({ error: null });
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ 
        user: state.user,
        isAuthenticated: state.isAuthenticated 
      }),
    }
  )
);